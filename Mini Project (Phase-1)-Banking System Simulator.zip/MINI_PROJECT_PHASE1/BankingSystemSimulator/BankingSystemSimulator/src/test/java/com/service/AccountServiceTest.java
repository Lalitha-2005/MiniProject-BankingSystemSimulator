package com.service;

import com.documents.Account;
import com.documents.Transaction;
import com.exceptions.AccountNotFoundException;
import com.exceptions.InsufficientBalanceException;
import com.exceptions.InvalidAmountException;
import com.repository.AccountRepository;
import com.repository.TransactionRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountServiceTest {

    @Autowired
 AccountRepository accountRepository;
    @Autowired
     TransactionRepository transactionRepository;
    @Autowired
     AccountService accountService;

    @BeforeEach
    void setup() {
        accountRepository = mock(AccountRepository.class);
        transactionRepository = mock(TransactionRepository.class);
        accountService = new AccountService(accountRepository, transactionRepository);
    }

    @Test
    void testCreateAccountSuccess() {
        Account account = new Account();
        account.setHolderName("Lalitha");

        when(accountRepository.findByAccountNumber(anyString())).thenReturn(Optional.empty());
        when(accountRepository.save(any(Account.class))).thenAnswer(i -> i.getArgument(0));

        Account saved = accountService.createAccount(account);

        assertNotNull(saved.getAccountNumber());
        assertEquals(0.0, saved.getBalance());
        verify(accountRepository, times(1)).save(any());
    }

    @Test
    void testCreateAccountNull() {
        assertThrows(IllegalArgumentException.class,
                () -> accountService.createAccount(null));
    }

    @Test
    void testCreateAccountHolderNameMissing() {
        Account acc = new Account();
        acc.setHolderName("");

        assertThrows(IllegalArgumentException.class,
                () -> accountService.createAccount(acc));
    }

    @Test
    void testGetAccountSuccess() {
        Account acc = new Account();
        acc.setAccountNumber("ANJ2488");

        when(accountRepository.findByAccountNumber("ANJ2488")).thenReturn(Optional.of(acc));

        Account fetched = accountService.getAccount("ANJ2488");

        assertEquals("ANJ2488", fetched.getAccountNumber());
    }

    @Test
    void testGetAccountNotFound() {
        when(accountRepository.findByAccountNumber("ANJ2488")).thenReturn(Optional.empty());

        assertThrows(AccountNotFoundException.class,
                () -> accountService.getAccount("ANJ2488"));
    }

    @Test
    void testDepositSuccess() {
        Account acc = new Account();
        acc.setAccountNumber("LAK7786");
        acc.setBalance(1000);

        when(accountRepository.findByAccountNumber("LAK7786")).thenReturn(Optional.of(acc));
        when(accountRepository.save(acc)).thenReturn(acc);

        Account updated = accountService.deposit("LAK7786", 500);

        assertEquals(1500, updated.getBalance());
        verify(transactionRepository, times(1)).save(any());
    }

    @Test
    void testDepositInvalidAmount() {
        assertThrows(InvalidAmountException.class,
                () -> accountService.deposit("ACC1", 0));
    }

    @Test
    void testWithdrawSuccess() {
        Account acc = new Account();
        acc.setAccountNumber("ACC1");
        acc.setBalance(2000);

        when(accountRepository.findByAccountNumber("ACC1")).thenReturn(Optional.of(acc));

        Account updated = accountService.withdraw("ACC1", 500);

        assertEquals(1500, updated.getBalance());
    }

    @Test
    void testWithdrawInsufficientBalance() {
        Account acc = new Account();
        acc.setAccountNumber("ACC1");
        acc.setBalance(300);

        when(accountRepository.findByAccountNumber("ACC1")).thenReturn(Optional.of(acc));

        assertThrows(InsufficientBalanceException.class,
                () -> accountService.withdraw("ACC1", 500));
    }

    @Test
    void testTransferSuccess() {
        Account fromAcc = new Account();
        fromAcc.setAccountNumber("A1");
        fromAcc.setBalance(2000);

        Account toAcc = new Account();
        toAcc.setAccountNumber("A2");
        toAcc.setBalance(1000);

        when(accountRepository.findByAccountNumber("A1")).thenReturn(Optional.of(fromAcc));
        when(accountRepository.findByAccountNumber("A2")).thenReturn(Optional.of(toAcc));

        String result = accountService.transfer("A1", "A2", 500);

        assertEquals("Transfer successful", result);
        assertEquals(1500, fromAcc.getBalance());
        assertEquals(1500, toAcc.getBalance());
    }

}
