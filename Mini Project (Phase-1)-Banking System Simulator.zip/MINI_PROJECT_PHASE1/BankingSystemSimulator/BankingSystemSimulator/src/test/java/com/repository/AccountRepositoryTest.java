package com.repository;

import com.documents.Account;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

@DataMongoTest
class AccountRepositoryTest {

    @Autowired
    AccountRepository accountRepository;

    @Test
    void testSaveAndFindAccount() {
        Account acc = new Account();
        acc.setAccountNumber("PAV8976");
        acc.setHolderName("Pavithra Devi");
        acc.setBalance(5000);
        acc.setStatus("ACTIVE");
        acc.setCreatedAt(Instant.now());

        accountRepository.save(acc);

        Account stored = accountRepository.findByAccountNumber("PAV8976").orElse(null);

        assertNotNull(stored);
        assertEquals("Pavithra Devi", stored.getHolderName());
        assertEquals(5000, stored.getBalance());
    }
}
