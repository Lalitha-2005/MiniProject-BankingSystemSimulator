package com.service;

import com.documents.Account;
import com.documents.Transaction;
import com.exceptions.AccountNotFoundException;
import com.exceptions.InsufficientBalanceException;
import com.exceptions.InvalidAmountException;
import com.repository.AccountRepository;
import com.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.Random;

@Service
public class AccountService {

   private final AccountRepository accountRepository;
    @Autowired
    TransactionRepository transactionRepository;

    public AccountService(AccountRepository accountRepository,
                          TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    // Create Account
    public Account createAccount(Account account) {

        if (account == null) {
            throw new IllegalArgumentException("Account object must not be null");
        }

        if (account.getHolderName() == null || account.getHolderName().trim().isEmpty()) {
            throw new IllegalArgumentException("Holder Name is required");
        }

        String accNumber = generateAccountNumber(account.getHolderName());

        // CHECK IF ACCOUNT ALREADY EXISTS — FIXED HERE
        Optional<Account> existing = accountRepository.findByAccountNumber(accNumber);
        if (existing.isPresent()) {
            throw new RuntimeException("Account already exists with number " + accNumber);
        }

        account.setAccountNumber(accNumber);
        account.setBalance(0.0);
        account.setStatus("ACTIVE");
        account.setCreatedAt(Instant.now());

        return accountRepository.save(account);
    }


    private String generateAccountNumber(String name) {
        String initials = name.trim().substring(0, Math.min(3, name.length())).toUpperCase();
        int randomNum = new Random().nextInt(9000) + 1000;  // generates 1000–9999
        return initials + randomNum;
    }

    // Get Account
    public Account getAccount(String accNo) {
        if (accNo == null || accNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Account number is required");
        }

        return accountRepository.findByAccountNumber(accNo)
                .orElseThrow(() -> new AccountNotFoundException(
                        "Account not found with account number: " + accNo
                ));
    }

    // Deposit
    public Account deposit(String accountNo, double amount) {
        if (amount <= 0) throw new InvalidAmountException("Amount must be greater than 0");

        Account acc = getAccount(accountNo);
        acc.setBalance(acc.getBalance() + amount);
        accountRepository.save(acc);

        saveTransaction(accountNo, "DEPOSIT", amount, "SUCCESS", null);

        return acc;
    }

    // Withdraw
    public Account withdraw(String accountNo, double amount) {
        if (amount <= 0) throw new InvalidAmountException("Amount must be greater than 0");

        Account acc = getAccount(accountNo);
        if (acc.getBalance() < amount)
            throw new InsufficientBalanceException("Insufficient balance!");

        acc.setBalance(acc.getBalance() - amount);
        accountRepository.save(acc);

        saveTransaction(accountNo, "WITHDRAW", amount, "SUCCESS", null);

        return acc;
    }

    // Transfer
    public String transfer(String fromAcc, String toAcc, double amount) {
        withdraw(fromAcc, amount);
        deposit(toAcc, amount);

        saveTransaction(fromAcc, "TRANSFER", amount, "SUCCESS", toAcc);

        return "Transfer successful";
    }

    // Helper to save transaction
    private void saveTransaction(String src, String type, double amount, String status, String dest) {
        Transaction txn = new Transaction();
        txn.setTransactionId("TXN-" + System.currentTimeMillis());
        txn.setType(type);
        txn.setAmount(amount);
        txn.setTimestamp(new Date());
        txn.setStatus(status);
        txn.setSourceAccount(src);
        txn.setDestinationAccount(dest);

        transactionRepository.save(txn);
    }

}
