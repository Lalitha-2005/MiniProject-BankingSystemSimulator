package com.controller;

import com.documents.Account;
import com.documents.Transaction;
import com.repository.TransactionRepository;
import com.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/account")
public class AccountController {
    @Autowired
    AccountService accountService;
    @Autowired
    TransactionRepository transactionRepository;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    // Create Account
    @PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Account createAccounts(@RequestBody Account account) {
        return accountService.createAccount(account);
    }

    // Get Account
    @GetMapping(value = "/findAccount/{accNo}")
    public Account findAccountDetailsUsingAccNo(@PathVariable("accNo") String accNo) {
        return accountService.getAccount(accNo);
    }

    // Deposit
    @PutMapping("/{accNo}/deposit")
    public Account deposit(@PathVariable String accNo,
                           @RequestParam double amount) {
        return accountService.deposit(accNo, amount);
    }

    // Withdraw
    @PutMapping("/{accNo}/withdraw")
    public Account withdraw(@PathVariable String accNo,
                            @RequestParam double amount) {
        return accountService.withdraw(accNo, amount);
    }

    // Transfer
    @PostMapping("/transfer")
    public String transfer(@RequestParam("fromAccount") String fromAccount,
                           @RequestParam("toAccount") String toAccount,
                           @RequestParam("amount") double amount) {
        return accountService.transfer(fromAccount, toAccount, amount);
    }

    //Transactions
    @GetMapping("/transactions/{accountNumber}")
    public List<Transaction> getTransactions(@PathVariable("accountNumber") String accountNumber) {

        return transactionRepository.findBySourceAccountOrDestinationAccount(accountNumber, accountNumber);
    }
}
